const observer = new MutationObserver(() => {
  const composeAreas = document.querySelectorAll('[aria-label="Message Body"]');

  composeAreas.forEach((area) => {
    if (!area.dataset.trackingInjected) {
      // Call your backend to get the tracking URL
      fetch("http://localhost:8080/trackingLink", {
        method: "GET",
        headers: {
          Authorization: `Bearer YOUR_JWT_TOKEN_HERE`, // Replace or inject from storage
        },
      })
        .then((res) => res.json())
        .then((data) => {
          const trackingImg = `<img src="${data.trackingUrl}" width="1" height="1" style="display:none;" />`;
          area.innerHTML += trackingImg;
          area.dataset.trackingInjected = "true";
          console.log("✅ Tracking pixel injected");
        })
        .catch((err) => {
          console.error("❌ Failed to fetch tracking pixel:", err);
        });
    }
  });
});

observer.observe(document.body, { childList: true, subtree: true });
